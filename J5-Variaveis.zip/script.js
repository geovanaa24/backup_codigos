// LOCALIZAR ELEMENTOS DO HTML
// CRIAR: EMAIL / TELEFONE / IDADE / SEXO
const nome = document.getElementById('nome')
const sobrenome = document.getElementById('sobrenome')
const gmai = document.getElementById('email')
const telefone = document.getElementById('telefone')
const idade = document.getElementById('idade')
const sexo = document.getElementById('sexo')

// CRIAR VARIAVEIS
const novoNome = "mary"
const novoSobrenome = "Silva"
const novoEmail = "mary.silva@gmail.com"
const novoTelefone = "41123409"
const novoIdade = "25"
const novoSexo = "F"

// ATRIBUIR VALORES AO HTML COM OS VALORES 
// DAS NOSSAS VARIAVEIS (innerText/innerHTML)
nome.innerText = novoNome
sobrenome.innerText = novoSobrenome
gmai.innerText = novoEmail
telefone.innerText = novoTelefone
idade.innerText = novoIdade
sexo.innerText = novoSexo
