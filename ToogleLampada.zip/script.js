//IDENTIFICAR OS ELEMENTOS DOM (ÁRVORE HTML)
const btnTrocar = document.getElementById('btn-trocar')
const lampada = document.getElementById('lampada')
let baseURL = "https://5cd9d641-a0b2-444c-96c7-b515b10c9a39-00-19mn1chf42lku.picard.replit.dev/"

alert(lampada.src)

btnTrocar.addEventListener('click', function() {
  // alert(lampada.src == baseURL + "lampada0.png") 
  if (lampada.src == baseURL + "lampada0.png") {
    lampada.src = "lampada02.png"
  } else {
    lampada.src = "lampada0.png"
  }
})